Page({
  data: {
    img_url: [],
    title:'',
    content: '',
    People:'0',
    Address:'',
    Time: '',
    people:false,
    where:false,
    isTime:false,

  },
  onLoad: function (options) {

  },
  input: function (e) {
    console.log(e.detail.value)
    this.setData({
      content: e.detail.value
    })
  },
  chooseimage: function () {
    var that = this;
    wx.chooseImage({
      count: 9, // 默认9  
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有  
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有  
      
      success: function (res) {
        //把每次选择的图push进数组
        let img_url = that.data.img_url;
        for (let i = 0; i < res.tempFilePaths.length; i++) {
          img_url.push(res.tempFilePaths[i])
        }
        that.setData({
          img_url: img_url
        })
        if (img_url.length > 0) {
          
          if (img_url.length == 3) {
            
            that.setData({
              hideAdd: 1
            })
          } else {
            console.log(res.tempFilePaths.length)
            that.setData({
              hideAdd: 0
            })
          }

          

        }

      }
    })
  },
  //发布按钮事件
  send: function () {
    var that = this;
    var user_id = wx.getStorageSync('userid')
    wx.showLoading({
      title: '上传中',
    })
    that.img_upload()
  },
  //图片上传
  img_upload: function () {
    let that = this;
    let img_url = that.data.img_url;
    let img_url_ok = [];
    //由于图片只能一张一张地上传，所以用循环
    for (let i = 0; i < img_url.length; i++) {
      wx.uploadFile({
        //路径填你上传图片方法的地址
        url: 'https://www.foodiesnotalone.cn/uploadImage.php',
        filePath: img_url[i],
        name: 'image',
        formData: {
          'session3rd': wx.getStorageSync('session3rd'),
          'sayingId': sayingId
        },
        success: function (res) {
          var data = JSON.parse(res.data)
          console.log('服务器：上传完成 ' + data.url)
          console.log(data)
          //把上传成功的图片的地址放入数组中
          img_url_ok.push(data.url)
          wx.hideLoading()
        },
        fail: function (res) {
          console.log('上传失败')
        }
      })

    }
  },
  people: function () {
    this.setData({
      people: true,
    })
  },
  where: function () {
    this.setData({
     where: true,
    })
  },
  isTime: function () {
    this.setData({
      isTime: true,
    })
  },
  confirm: function () {// 确定
    this.setData({
      people: false,
      isTime:false,
      where:false,
    })
  },


  timeChange(e) {
    this.setData({
      Time: e.detail.value,
    })
  },
  
  peopleChange(e){
    this.setData({
      People: e.detail.value,
    })
  },
  whereChange(e){
    this.setData({
      Address: e.detail.value,
    })
  }
})
